define({ "api": [
  {
    "type": "POST",
    "url": "/api/posts",
    "title": "",
    "group": "创建_post",
    "version": "0.0.0",
    "filename": "src/controller/PostController.ts",
    "groupTitle": "创建_post",
    "name": "PostApiPosts",
    "sampleRequest": [
      {
        "url": "http://127.0.0.1:3000/api/posts"
      }
    ]
  },
  {
    "type": "POST",
    "url": "/api/posts/:id/comments",
    "title": "",
    "group": "创建_post_的评论",
    "version": "0.0.0",
    "filename": "src/controller/PostController.ts",
    "groupTitle": "创建_post_的评论",
    "name": "PostApiPostsIdComments",
    "sampleRequest": [
      {
        "url": "http://127.0.0.1:3000/api/posts/:id/comments"
      }
    ]
  },
  {
    "type": "DELETE",
    "url": "/api/posts/:id",
    "title": "",
    "group": "删除_post",
    "version": "0.0.0",
    "filename": "src/controller/PostController.ts",
    "groupTitle": "删除_post",
    "name": "DeleteApiPostsId",
    "sampleRequest": [
      {
        "url": "http://127.0.0.1:3000/api/posts/:id"
      }
    ]
  },
  {
    "type": "DELETE",
    "url": "/api/posts/comments/:id",
    "title": "",
    "group": "删除_post_的评论",
    "version": "0.0.0",
    "filename": "src/controller/PostController.ts",
    "groupTitle": "删除_post_的评论",
    "name": "DeleteApiPostsCommentsId",
    "sampleRequest": [
      {
        "url": "http://127.0.0.1:3000/api/posts/comments/:id"
      }
    ]
  },
  {
    "type": "PUT",
    "url": "/api/posts/:id",
    "title": "",
    "group": "更新_post",
    "version": "0.0.0",
    "filename": "src/controller/PostController.ts",
    "groupTitle": "更新_post",
    "name": "PutApiPostsId",
    "sampleRequest": [
      {
        "url": "http://127.0.0.1:3000/api/posts/:id"
      }
    ]
  },
  {
    "type": "POST",
    "url": "/api/posts/:id/comments",
    "title": "",
    "group": "添加_post_收藏",
    "version": "0.0.0",
    "filename": "src/controller/PostController.ts",
    "groupTitle": "添加_post_收藏",
    "name": "PostApiPostsIdComments",
    "sampleRequest": [
      {
        "url": "http://127.0.0.1:3000/api/posts/:id/comments"
      }
    ]
  },
  {
    "type": "POST",
    "url": "/api/users/register",
    "title": "",
    "group": "用户注册",
    "version": "0.0.0",
    "filename": "src/controller/UserController.ts",
    "groupTitle": "用户注册",
    "name": "PostApiUsersRegister",
    "sampleRequest": [
      {
        "url": "http://127.0.0.1:3000/api/users/register"
      }
    ]
  },
  {
    "type": "POST",
    "url": "/api/users/login",
    "title": "",
    "group": "登录",
    "version": "0.0.0",
    "filename": "src/controller/UserController.ts",
    "groupTitle": "登录",
    "name": "PostApiUsersLogin",
    "sampleRequest": [
      {
        "url": "http://127.0.0.1:3000/api/users/login"
      }
    ]
  },
  {
    "type": "get",
    "url": "/api/posts/:id",
    "title": "",
    "group": "获取单个_posts",
    "version": "0.0.0",
    "filename": "src/controller/PostController.ts",
    "groupTitle": "获取单个_posts",
    "name": "GetApiPostsId",
    "sampleRequest": [
      {
        "url": "http://127.0.0.1:3000/api/posts/:id"
      }
    ]
  },
  {
    "type": "GET",
    "url": "/api/users/:id",
    "title": "",
    "group": "获取单个用户",
    "version": "0.0.0",
    "filename": "src/controller/UserController.ts",
    "groupTitle": "获取单个用户",
    "name": "GetApiUsersId",
    "sampleRequest": [
      {
        "url": "http://127.0.0.1:3000/api/users/:id"
      }
    ]
  },
  {
    "type": "get",
    "url": "/api/posts",
    "title": "",
    "group": "获取所有post",
    "version": "0.0.0",
    "filename": "src/controller/PostController.ts",
    "groupTitle": "获取所有post",
    "name": "GetApiPosts",
    "sampleRequest": [
      {
        "url": "http://127.0.0.1:3000/api/posts"
      }
    ]
  },
  {
    "type": "GET",
    "url": "/api/users",
    "title": "",
    "group": "获取所有user",
    "version": "0.0.0",
    "filename": "src/controller/UserController.ts",
    "groupTitle": "获取所有user",
    "name": "GetApiUsers",
    "sampleRequest": [
      {
        "url": "http://127.0.0.1:3000/api/users"
      }
    ]
  }
] });
