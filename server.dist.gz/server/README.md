# Awesome Project Build with TypeORM

Steps to run this project:

1. Run `npm i` command
2. Setup database settings inside `ormconfig.json` file
3. Run `npm start` command

sql:
 
* 删除  delete from 表名
1. 安装mysql 服务器端：

          yum -y install mysql-server mysql-devel

2. 安装mysql客户端：

                   yum install mysql

3. 启动mysql服务：

          service mysqld start或者/etc/init.d/mysqld start

停止：

          service mysqld stop

重启：

          service mysqld restart
