import { Request } from "express";
import { Post } from "../entity/Post";
import { PostMetadata } from "../entity/PostMetadata";
import { validate } from "class-validator";
import {
  throwInputError,
  throwActionNotAllowedError
} from "../utils/throwError";
import { User } from "../entity/User";
import { Comment } from "../entity/Comment";
import _ from 'lodash'
import { Like } from "typeorm";
import { encode }  from '../utils/crypto';

export class PostController {
  async tags(req:Request){
    let { category } = req.query as any;
    const tags = await Post.find({ 
      select: ["tag"],
      where: { category }
    });
    const res = _.uniqWith(tags,_.isEqual);
    return res.map((item,index)=>({
      ...item,
      index: index+1
    }));
  }
  async categorys(){
    const categorys = await Post.find({ 
      select: ["category"]
    });
    const res = _.uniqWith(categorys,_.isEqual);
    return res.map((item,index)=>({
      ...item,
      index: index+1
    }));
  }
  /**
   * @api {get} /api/posts
   * @apiGroup 获取所有post 
  */
  async all(req: Request) {
    let { current, pageSize , tag, sort,keyword, category } = req.query as any;
    [current, pageSize] = [+current, +pageSize];

    const order = (+sort===0||typeof sort==="undefined")?{ createAt: "DESC" }: {readNum: "DESC"}
    let where = {};
    if(tag){
      where = Object.assign(where,{tag});
    }
    if(keyword){
      where = Object.assign(where,{title: Like('%' + keyword + '%')});
    }
    if(category){
      where = Object.assign(where, { 
        category
      });
    }
    let limit:any = {
      take: pageSize||10, // take limit 
      skip: (current - 1) * pageSize, // skip offset
      order,
      where
    };
    const data = await Post.findAndCount(limit);
    const count = await Post.count();
    const result =  data[0];
    return encode(JSON.stringify({ result, count ,pageSize,current}));
  }

  /**
   * @api {get} /api/posts/:id
   * @apiGroup 获取单个 posts
   */
  async one(request: Request){
    const res = await PostMetadata.findOneOrFail({
      where: { postId: String(request.params.id)},
      relations: ["comments"]
    });
    return res;
  }
  /**
   * @api {DELETE} /api/posts/:id
   * @apiGroup 删除 post
  */
  async remove(req: Request) {
    const post = await Post.findOneOrFail(req.params.id);
    // const currentUser = req.currentUser as User;

    // if (post.user.id !== currentUser.id) {
    //   throwActionNotAllowedError();
    // }

    await Post.remove(post);
    return { message: "deleted sucessfully" };
  }

  /**
   * @api {PUT} /api/posts/:id
   * @apiGroup 更新 post
  */
  async update(req: Request): Promise<Post> {
    const { body } = req.body;
    const post = await Post.findOneOrFail(req.params.id);
    post.body = body;

    // const currentUser = req.currentUser as User;

    const errors = await validate(post);

    if (errors.length > 0) {
      throwInputError(errors, "Post input error");
    }

    // if (post.user.id !== currentUser.id) {
    //   throwActionNotAllowedError();
    // }

    return await Post.save(post);
  }
  /**
   * @api {POST} /api/posts
   * @apiGroup 创建 post
  */
  async create(req: Request){
    const currentUser = req.currentUser as User;
    console.log('currentUser', currentUser);
    const { 
      from,
      category,
      tag,
      body,
      title,
      author,
      authorTitle,
      thumbImage,
      createAt,
      readNum,
      classSynopsis,
      classContent,
      isStrict,
      classImg,
      crowd,
      originalId,
      original,
    } = req.body;

    let post:any = new Post();
    const saveData:any = { from, category, tag, body, title, author, authorTitle, thumbImage, createAt, readNum};
    Object.keys(saveData).forEach(item=>{
      post[item] = saveData[item];
    });
    // post.user = currentUser;
    const errors = await validate(post);

    if (errors.length > 0) {
      throwInputError(errors, "Post input error");
    }
    const postData = await Post.save(post);
    const detail = {
      ...saveData,
      postId:postData.id,
      classSynopsis,
      isStrict,
      classImg,
      crowd,
      classContent,
      originalId,
      original
    }
    const detailData = await this.createPostDetails(detail);
    return {...postData,detailData};
  }
  // 创建post详情
  async createPostDetails(detail:any){
    let postMetadata:any = new PostMetadata();
    Object.keys(detail).forEach(item=>{
      postMetadata[item] = detail[item];
    });
    const errors = await validate(postMetadata);
    if (errors.length > 0) {
      throwInputError(errors, "Post input error");
    }
    return await postMetadata.save(detail)
  }

  async getPostDetail(){

  }
  
  /**
   * @api {POST} /api/posts/:id/comments
   * @apiGroup 创建 post 的评论
  */
  async createComment(req: Request): Promise<Comment> {
    const currentUser = req.currentUser as User;
    const { body } = req.body;
    const postMetadata = await PostMetadata.findOneOrFail({
      where: { postId: String(req.params.id)}
    });
    
    let comment = new Comment();
    comment.body = body;
    comment.user = currentUser;
    comment.postMetadata = postMetadata;

    const errors = await validate(comment);

    if (errors.length > 0) {
      throwInputError(errors, "Comment input error");
    }

    return await Comment.save(comment);
  }

  /**
   * @api {DELETE} /api/posts/comments/:id
   * @apiGroup 删除 post 的评论
  */
  async removeComment(req: Request) {
    const comment = await Comment.findOneOrFail(req.params.id);
    const currentUser = req.currentUser as User;

    if (comment.user.id !== currentUser.id) {
      throwActionNotAllowedError();
    }

    await Comment.remove(comment);
    return { message: "deleted sucessfully" };
  }

  /**
   * @api {POST} /api/posts/:id/comments
   * @apiGroup 添加 post 收藏
  */
  async likePost(req: Request): Promise<PostMetadata> {
    const currentUser = req.currentUser as User;
    const post= await PostMetadata.findOneOrFail(req.params.id, {
      relations: ["likes"]
    });

    if (post.likes && post.likes.find(like => like.id === currentUser.id)) {
      post.likes = post.likes.filter(like => like.id !== currentUser.id);
    } else {
      post.likes = [...post.likes, currentUser];
    }

    return await PostMetadata.save(post);
  }
}