import { Request } from "express";
import { User } from "../entity/User";
import { validate } from "class-validator";
import { Session } from "./../models/Session";
import { throwInputError } from "../utils/throwError";
import httpService from "../utils/httpService";
import qs from 'qs';

export class UserController {
  /**
   * @api {GET} /api/users
   * @apiGroup 获取所有user
  */
  async all(_: Request) {
    return await User.find({ relations: ["posts"] });
  }
  /**
   * @api {POST} /api/users/login
   * @apiGroup 登录
  */
  async login(req: Request) {
    const { username, password } = req.body;

    let session = new Session();
    session.username = username;
    session.password = password;

    const errors = await validate(session);

    if (errors.length > 0) {
      throwInputError(errors, "User login input error");
    }

    const user = await User.findOneOrFail({ username });

    return { id: user.id, username: user.username, token: user.token };
  }
  /**
   * @api {POST} /api/users/wxLogin
   * @apiGroup 微信登录
  */
  async wxLogin(req: Request) {
    let { code } =  req.body;
    const loginRes:any = await httpService.post('http://open.51094.com/user/auth.html',qs.stringify({
      type:"get_user_info",
      code,
      appid: "15f1ab651a5518",
      token: "8d3a1c15ecd785c20d3cfa11f10fc9ef"
    }),{
      "Content-Type":'application/x-www-form-urlencoded; charset=UTF-8'
    });
  
    if(!loginRes.name){
      return loginRes;
    }else{
      let session = new Session();
      session.username = loginRes.name;
      session.password = loginRes.uniq;
      const errors = await validate(session);

      if (errors.length > 0) {
        throwInputError(errors, "User login input error");
      }
      const user:any = await User.findOne({ username:loginRes.name});

      if(user&&user.username){
        return { id: user.id, username: user.username, token: user.token, portrait: user.email };
      }
      try{ 
        const register: any = await httpService.post(`http://127.0.0.1:3000/api/users/register`,{
          username: loginRes.name,
          password: loginRes.uniq,
          email: loginRes.img,
          confirmPassword:loginRes.uniq,
        });
        if(+register.error_code===0){
          const user = await User.findOneOrFail({ username:loginRes.name});
          return { id: user.id, username: user.username, token: user.token,portrait: user.email };
        }
      }catch(error){
        console.log('error', error);
      }
    }
  }
  /**
   * @api {POST} /api/users/register
   * @apiGroup 用户注册
  */
  async register(req: Request) {
    const { username, password, confirmPassword, email } = req.body;

    let user = new User();
    user.username = username;
    user.password = password;
    user.confirmPassword = confirmPassword;
    user.email = email;

    const errors = await validate(user);

    if (errors.length > 0) {
      throwInputError(errors, "User register input error");
    }

    await user.save();

    return { id: user.id, username: user.username, token: user.token };
  }

  /**
   * @api {GET} /api/users/:id
   * @apiGroup 获取单个用户
  */
  async one(request: Request): Promise<User> {
    return await User.findOneOrFail(request.params.id);
  }
}
