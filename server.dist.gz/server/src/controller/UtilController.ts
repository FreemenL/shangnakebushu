import { Request } from "express";
import httpService from "../utils/httpService";
import { readercodeApi } from '../utils/const'
import qs from 'qs';

export class UtilController {
  async getQrcode(){
    const qrcode = await httpService.get("https://www.qijinlai.com/wxlogin/wxlogin.php");
    return qrcode;
  }
  async parseCode(req:Request){
    let res:any;
    let { url } = req.body;
    try {
      res = await httpService.post(readercodeApi,qs.stringify({data:url}),{
        "Content-Type":'application/x-www-form-urlencoded; charset=UTF-8'
      });
    } catch (error) {
      console.log('err :>> ', error);
    }
    return {url:res.data.RawData}
  } 
}