import { Entity, Column, ManyToOne } from "typeorm";
import { IsNotEmpty } from "class-validator";
import { User } from "./User";
import { PostMetadata } from "./PostMetadata";
import Base from "./Base";

@Entity("comments")
export class Comment extends Base {
  @Column("text")
  @IsNotEmpty()
  body: string;

  @ManyToOne(
    () => User,
    user => user.comments,
    { eager: true }
  )
  @IsNotEmpty()
  user: User;

  @ManyToOne(
    () => PostMetadata,
    post => post.comments,
    { onDelete: "CASCADE" }
  )
  @IsNotEmpty()
  postMetadata: PostMetadata;
}
