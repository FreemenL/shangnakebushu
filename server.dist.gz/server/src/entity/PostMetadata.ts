import {
  Entity,
  Column,
  OneToMany,
  ManyToMany,
  JoinTable,
} from "typeorm";
import { User } from "./User";
import { Comment } from "./Comment";
import { IsNotEmpty } from "class-validator";
import Base from "./Base";


@Entity("post_metadata")
export class PostMetadata extends Base {

  @Column({ comment:"post_id" }) 
  @IsNotEmpty()
  postId: string;

  @Column({comment:"作者"}) 
  @IsNotEmpty()
  author: string;

  @Column({comment:"作者title"})
  @IsNotEmpty()
  authorTitle: string;

  @Column({comment:"文章分类"})
  @IsNotEmpty()
  category: string;

  @Column({comment:"文章tag"})
  @IsNotEmpty()
  tag: string;

  @Column({comment:"头像"})
  @IsNotEmpty()
  thumbImage: string;

  @Column({comment:"发布时间"})
  @IsNotEmpty()
  createAt: string;

  @Column({comment:"已购数量"})
  @IsNotEmpty()
  readNum: number;

  @Column({comment:"title"})
  @IsNotEmpty()
  title: string;

  @Column({comment:"来源"}) 
  @IsNotEmpty()
  from: string;

  @Column({comment:"课程简介"}) 
  @IsNotEmpty()
  classSynopsis: string;

  @Column({ type: 'text' ,comment:"课程内容"}) 
  classContent: string;

  @Column({comment:"是否严选"}) 
  @IsNotEmpty()
  isStrict: Boolean;

  @Column({comment:"课程图片"})
  classImg: string;

  @Column({comment:"适合人群"})
  @IsNotEmpty()
  crowd: string;

  @Column({comment:"原文链接"})
  @IsNotEmpty()
  original: string;

  @Column({comment:"原文Id"})
  @IsNotEmpty()
  originalId: string;

  // 课程评价
  @OneToMany(
    () => Comment,
    comment => comment.postMetadata
  )
  comments: Comment[];
    
  @ManyToMany(() => User)
  @JoinTable()
  likes: User[];
}
