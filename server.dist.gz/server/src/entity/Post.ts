import {
  Entity,
  Column
} from "typeorm";
import { IsPostAlreadyExist } from "../utils/validators/decorators/IsPostAlreadyExist";
import { IsNotEmpty } from "class-validator";

import Base from "./Base";

@Entity("posts")
export class Post extends Base {
  
  @Column({comment:"作者"}) 
  @IsNotEmpty()
  author: string;

  @Column({comment:"作者title"})
  @IsNotEmpty()
  authorTitle: string;

  @Column({comment:"文章分类"})
  @IsNotEmpty()
  category: string;

  @Column({comment:"文章tag"})
  @IsNotEmpty()
  tag: string;

  @Column({comment:"头像"})
  @IsNotEmpty()
  thumbImage: string;

  @Column({comment:"发布时间"})
  @IsNotEmpty()
  createAt: string;

  @Column({comment:"已够数量"})
  @IsNotEmpty()
  readNum: number;

  @Column({comment:"title"})
  @IsNotEmpty()
  @IsPostAlreadyExist(false,{
    message: "Post $value already exists. Choose another name."
  })
  title: string;

  @Column({comment:"来源"}) 
  @IsNotEmpty()
  from: string;

  @Column("text")
  @IsNotEmpty()
  body: string;

  // @ManyToOne(
  //   _ => User,
  //   user => user.posts,
  //   // { eager: true }
  // )
  // @JoinColumn({ name: "user_id" })
  // @IsNotEmpty()
  // user: User;
}
