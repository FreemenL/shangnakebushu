import { Application } from "./app";

new Application().setupDbAndServer();

