import crypto from "crypto";

export function encode(text:string,key?:string){
	var secret = key || "4C31F7EFD6857D91E729165510520424*admin";
	var cipher = crypto.createCipher('aes-256-cbc',secret);
	var crypted =cipher.update(text,'utf8','hex');
	crypted+=cipher.final('hex');
	return crypted;
};