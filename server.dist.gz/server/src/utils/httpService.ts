import axios from "axios";
// import { readercodeApi } from './const'
// 添加请求拦截器

class httpService {
  static get(url:string, data?:any, config?:{}){
    return httpService.fetch('get')(url, data, config)
  }
  static post(url:string, data:any, config={}){
    return httpService.fetch('post')(url, data, config)
  }
  static fetch(method:string){
    return function(url:string, data:any, config?:object){
      return new Promise((resolve, reject) => {
        (axios as any)[method](url, data, config)
          .then((result:any) => {
            if(result.data){
              return resolve(result.data);
            }else if(typeof result.data ==="string"){
              return resolve(result.data);
            }
            reject(result.data.message);
          })
          .catch((result:any) => {
            reject(result);
          })
      });
    }
  }
}

export default httpService;
