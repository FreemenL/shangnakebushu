import {
  registerDecorator,
  ValidationOptions,
  ValidatorConstraint,
  ValidatorConstraintInterface,
  ValidationArguments
} from "class-validator";
import { Post } from "../../../entity/Post";

@ValidatorConstraint({ async: true })
export class IsUserAlreadyExistConstraint
  implements ValidatorConstraintInterface {
  async validate(title: string, args: ValidationArguments) {
    const [flag] = args.constraints;
    const post = await Post.find({ title });
    if (post.length>0) return flag;
    return !flag;
  }
}

export function IsPostAlreadyExist(
  flag: boolean,
  validationOptions?: ValidationOptions
) {
  return function(object: Object, propertyName: string) {
    registerDecorator({
      target: object.constructor,
      propertyName: propertyName,
      options: validationOptions,
      constraints: [flag],
      validator: IsUserAlreadyExistConstraint
    });
  };
}
