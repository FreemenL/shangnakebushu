import { Request, Response, NextFunction } from "express";
import HttpException from "../exceptions/HttpException";
import { NOT_FOUND } from "http-status-codes";

export default function remoteAddress(
  _req: Request,
  _res: Response,
  next: NextFunction
) {
  const remoteIP = _req.ip;
  if(!remoteIP.includes('127.0.0.1')){
    const error: HttpException = new HttpException(NOT_FOUND, "Router Not Found");
    return next(error);
  }
  next();
}