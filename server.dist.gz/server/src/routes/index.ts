import usersRoute from "./users";
import postsRoute from "./posts";
import utilsRoute from "./utils";

export default [...usersRoute, ...postsRoute,...utilsRoute];
