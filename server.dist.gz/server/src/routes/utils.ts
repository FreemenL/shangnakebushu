import { UtilController } from "../controller/UtilController";
// import checkAuth from "../middlewares/check-auth";

const utilsRoute = [
  {
    method: "post",
    route: "/utils/parseCode",
    middlewares: [],
    controller: UtilController,
    action: "parseCode"
  },
  {
    method: "get",
    route: "/utils/getQrcode",
    middlewares: [],
    controller: UtilController,
    action: "getQrcode"
  }
];

export default utilsRoute;
